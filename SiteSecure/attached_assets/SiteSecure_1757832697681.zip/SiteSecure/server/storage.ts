import { 
  users, 
  contentSections, 
  donations, 
  licenseKeys, 
  contactMessages,
  type User, 
  type InsertUser,
  type ContentSection,
  type InsertContentSection,
  type Donation,
  type InsertDonation,
  type LicenseKey,
  type InsertLicenseKey,
  type ContactMessage,
  type InsertContactMessage
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsersByRole(role: string): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  deleteUser(id: string): Promise<void>;
  
  // Content operations
  getContentByPage(page: string): Promise<ContentSection[]>;
  createContentSection(content: InsertContentSection): Promise<ContentSection>;
  updateContentSection(id: string, content: Partial<InsertContentSection>): Promise<ContentSection>;
  deleteContentSection(id: string): Promise<void>;
  
  // Donation operations
  createDonation(donation: InsertDonation): Promise<Donation>;
  getAllDonations(): Promise<Donation[]>;
  
  // License key operations
  validateLicenseKey(keyValue: string): Promise<boolean>;
  createLicenseKey(key: InsertLicenseKey): Promise<LicenseKey>;
  
  // Contact message operations
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getAllContactMessages(): Promise<ContactMessage[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private contentSections: Map<string, ContentSection>;
  private donations: Map<string, Donation>;
  private licenseKeys: Map<string, LicenseKey>;
  private contactMessages: Map<string, ContactMessage>;

  constructor() {
    this.users = new Map();
    this.contentSections = new Map();
    this.donations = new Map();
    this.licenseKeys = new Map();
    this.contactMessages = new Map();
    
    // Initialize with default owner account and license key
    this.initializeDefaults();
  }

  private async initializeDefaults() {
    // Create default owner account
    const ownerId = randomUUID();
    const defaultOwner: User = {
      id: ownerId,
      username: "owner",
      email: "owner@missionconnect.org",
      password: "$2b$10$rQY8VzJqZ8Zq8Zq8Zq8Zq8", // hashed "owner123"
      role: "owner",
      fullName: "System Owner",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(ownerId, defaultOwner);

    // Create default license key
    const keyId = randomUUID();
    const defaultKey: LicenseKey = {
      id: keyId,
      keyValue: "MISSION-2024-ACTIVATED",
      isActive: true,
      activatedAt: null,
      expiresAt: null,
      createdAt: new Date(),
    };
    this.licenseKeys.set(keyId, defaultKey);

    // Initialize default content
    this.initializeDefaultContent();
  }

  private initializeDefaultContent() {
    const defaultContent = [
      {
        id: randomUUID(),
        page: "homepage",
        section: "hero",
        title: "Making a Difference, One Mission at a Time",
        description: "Join our community of changemakers as we work together to create lasting impact in communities around the world.",
        imageUrl: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
        content: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: randomUUID(),
        page: "homepage",
        section: "stats",
        title: "Impact Stats",
        description: "",
        imageUrl: null,
        content: {
          stats: [
            { value: "50K+", label: "Lives Impacted" },
            { value: "25", label: "Countries Reached" },
            { value: "100+", label: "Projects Completed" },
            { value: "1M+", label: "Funds Raised" }
          ]
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      }
    ];

    defaultContent.forEach(content => {
      this.contentSections.set(content.id, content);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === role,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      role: insertUser.role || "user",
      fullName: insertUser.fullName || null,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async deleteUser(id: string): Promise<void> {
    this.users.delete(id);
  }

  async getContentByPage(page: string): Promise<ContentSection[]> {
    return Array.from(this.contentSections.values()).filter(
      (content) => content.page === page,
    );
  }

  async createContentSection(insertContent: InsertContentSection): Promise<ContentSection> {
    const id = randomUUID();
    const content: ContentSection = {
      ...insertContent,
      title: insertContent.title || null,
      description: insertContent.description || null,
      imageUrl: insertContent.imageUrl || null,
      content: insertContent.content || null,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.contentSections.set(id, content);
    return content;
  }

  async updateContentSection(id: string, updateData: Partial<InsertContentSection>): Promise<ContentSection> {
    const existing = this.contentSections.get(id);
    if (!existing) {
      throw new Error("Content section not found");
    }
    
    const updated: ContentSection = {
      ...existing,
      ...updateData,
      updatedAt: new Date(),
    };
    this.contentSections.set(id, updated);
    return updated;
  }

  async deleteContentSection(id: string): Promise<void> {
    this.contentSections.delete(id);
  }

  async createDonation(insertDonation: InsertDonation): Promise<Donation> {
    const id = randomUUID();
    const donation: Donation = {
      ...insertDonation,
      status: insertDonation.status || "pending",
      currency: insertDonation.currency || "USD",
      message: insertDonation.message || null,
      paymentIntentId: insertDonation.paymentIntentId || null,
      donorName: insertDonation.donorName || null,
      id,
      createdAt: new Date(),
    };
    this.donations.set(id, donation);
    return donation;
  }

  async getAllDonations(): Promise<Donation[]> {
    return Array.from(this.donations.values());
  }

  async validateLicenseKey(keyValue: string): Promise<boolean> {
    const key = Array.from(this.licenseKeys.values()).find(
      (k) => k.keyValue === keyValue && k.isActive
    );
    
    if (key && !key.activatedAt) {
      // Mark as activated
      key.activatedAt = new Date();
      this.licenseKeys.set(key.id, key);
    }
    
    return !!key;
  }

  async createLicenseKey(insertKey: InsertLicenseKey): Promise<LicenseKey> {
    const id = randomUUID();
    const key: LicenseKey = {
      ...insertKey,
      isActive: insertKey.isActive !== undefined ? insertKey.isActive : true,
      activatedAt: insertKey.activatedAt || null,
      expiresAt: insertKey.expiresAt || null,
      id,
      createdAt: new Date(),
    };
    this.licenseKeys.set(id, key);
    return key;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = randomUUID();
    const message: ContactMessage = {
      ...insertMessage,
      status: insertMessage.status || "unread",
      id,
      createdAt: new Date(),
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getAllContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }
}

export const storage = new MemStorage();
