import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, requireAuth, requireRole } from "./auth";
import Stripe from "stripe";
import multer from "multer";
import path from "path";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertContentSectionSchema, 
  insertDonationSchema,
  insertContactMessageSchema,
  loginSchema,
  productKeySchema 
} from "@shared/schema";

// Setup file upload
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Setup Stripe (conditional)
let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2024-06-20",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // PayPal routes
  app.get("/api/paypal/setup", async (req, res) => {
    const { loadPaypalDefault } = await import("./paypal");
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    const { createPaypalOrder } = await import("./paypal");
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    const { capturePaypalOrder } = await import("./paypal");
    await capturePaypalOrder(req, res);
  });

  // Stripe payment route
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!stripe) {
      return res.status(503).json({ message: "Stripe is not configured" });
    }
    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Product key validation
  app.post("/api/validate-license", async (req, res) => {
    try {
      const validatedData = productKeySchema.parse(req.body);
      const isValid = await storage.validateLicenseKey(validatedData.keyValue);
      
      if (isValid) {
        res.json({ valid: true, message: "License activated successfully" });
      } else {
        res.status(400).json({ valid: false, message: "Invalid or expired license key" });
      }
    } catch (error) {
      res.status(400).json({ valid: false, message: "Invalid request" });
    }
  });

  // Content management routes (Admin only)
  app.get("/api/content/:page", async (req, res) => {
    try {
      const content = await storage.getContentByPage(req.params.page);
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.post("/api/content", requireRole(['admin', 'owner']), async (req, res) => {
    try {
      const validatedData = insertContentSectionSchema.parse(req.body);
      const content = await storage.createContentSection(validatedData);
      res.status(201).json(content);
    } catch (error) {
      res.status(400).json({ message: "Invalid content data" });
    }
  });

  app.put("/api/content/:id", requireRole(['admin', 'owner']), async (req, res) => {
    try {
      const validatedData = insertContentSectionSchema.parse(req.body);
      const content = await storage.updateContentSection(req.params.id, validatedData);
      res.json(content);
    } catch (error) {
      res.status(400).json({ message: "Failed to update content" });
    }
  });

  // File upload route (Admin only)
  app.post("/api/upload", requireRole(['admin', 'owner']), upload.single('image'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    
    // In production, you'd upload to a cloud service like AWS S3
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({ url: fileUrl });
  });

  // Admin management routes (Owner only)
  app.post("/api/admin", requireRole(['owner']), async (req, res) => {
    try {
      const userData = { ...req.body, role: 'admin' };
      const validatedData = insertUserSchema.parse(userData);
      const admin = await storage.createUser(validatedData);
      res.status(201).json(admin);
    } catch (error) {
      res.status(400).json({ message: "Failed to create admin account" });
    }
  });

  app.get("/api/admins", requireRole(['owner']), async (req, res) => {
    try {
      const admins = await storage.getUsersByRole('admin');
      res.json(admins);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admins" });
    }
  });

  app.delete("/api/admin/:id", requireRole(['owner']), async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.json({ message: "Admin deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete admin" });
    }
  });

  // Donation routes
  app.post("/api/donations", async (req, res) => {
    try {
      const validatedData = insertDonationSchema.parse(req.body);
      const donation = await storage.createDonation(validatedData);
      res.status(201).json(donation);
    } catch (error) {
      res.status(400).json({ message: "Invalid donation data" });
    }
  });

  app.get("/api/donations", requireRole(['admin', 'owner']), async (req, res) => {
    try {
      const donations = await storage.getAllDonations();
      res.json(donations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch donations" });
    }
  });

  // Contact form routes
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid contact data" });
    }
  });

  app.get("/api/contact", requireRole(['admin', 'owner']), async (req, res) => {
    try {
      const messages = await storage.getAllContactMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
