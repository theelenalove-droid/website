import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { KeyRound } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ProductKeyModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [productKey, setProductKey] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    // Check if license is already activated
    const licenseActivated = localStorage.getItem("missionconnect_license_activated");
    if (!licenseActivated) {
      setIsOpen(true);
    }
  }, []);

  const validateKeyMutation = useMutation({
    mutationFn: async (keyValue: string) => {
      const res = await apiRequest("POST", "/api/validate-license", { keyValue });
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.valid) {
        localStorage.setItem("missionconnect_license_activated", "true");
        setIsOpen(false);
        toast({
          title: "License Activated",
          description: "Full functionality has been unlocked!",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Invalid License Key",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (productKey.trim()) {
      validateKeyMutation.mutate(productKey.trim());
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" data-testid="product-key-modal">
        <DialogHeader className="text-center">
          <div className="mx-auto mb-4 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <KeyRound className="h-8 w-8 text-primary" />
          </div>
          <DialogTitle className="text-2xl">License Activation Required</DialogTitle>
          <p className="text-muted-foreground">
            Enter your product key to unlock full functionality
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            type="text"
            placeholder="Enter your product key"
            value={productKey}
            onChange={(e) => setProductKey(e.target.value)}
            data-testid="product-key-input"
          />
          
          <Button 
            type="submit" 
            className="w-full"
            disabled={validateKeyMutation.isPending}
            data-testid="activate-license-button"
          >
            {validateKeyMutation.isPending ? "Activating..." : "Activate License"}
          </Button>
        </form>
        
        <div className="text-xs text-muted-foreground text-center">
          Contact support if you need assistance with your license key
        </div>
      </DialogContent>
    </Dialog>
  );
}
