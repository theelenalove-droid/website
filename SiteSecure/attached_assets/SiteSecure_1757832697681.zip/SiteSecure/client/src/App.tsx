import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import Navigation from "@/components/Navigation";
import ProductKeyModal from "@/components/ProductKeyModal";
import HomePage from "@/pages/home-page";
import AboutPage from "@/pages/about-page";
import WorkPage from "@/pages/work-page";
import StoriesPage from "@/pages/stories-page";
import RecognitionPage from "@/pages/recognition-page";
import DonatePage from "@/pages/donate-page";
import ContactPage from "@/pages/contact-page";
import AuthPage from "@/pages/auth-page";
import OwnerDashboard from "@/pages/owner-dashboard";
import AdminDashboard from "@/pages/admin-dashboard";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/work" component={WorkPage} />
      <Route path="/stories" component={StoriesPage} />
      <Route path="/recognition" component={RecognitionPage} />
      <Route path="/donate" component={DonatePage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/admin-secret-portal" component={AuthPage} />
      <ProtectedRoute path="/owner-dashboard" component={OwnerDashboard} requiredRole="owner" />
      <ProtectedRoute path="/admin-dashboard" component={AdminDashboard} requiredRole="admin" />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <div className="min-h-screen bg-background">
            <ProductKeyModal />
            <Navigation />
            <main>
              <Router />
            </main>
            <footer className="bg-foreground text-background py-12">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid md:grid-cols-4 gap-8">
                  <div>
                    <h3 className="text-xl font-bold mb-4">MissionConnect</h3>
                    <p className="text-background/80 mb-4">
                      Creating lasting change in communities worldwide through sustainable development and humanitarian aid.
                    </p>
                    <div className="flex space-x-4">
                      <a href="#" className="text-background/80 hover:text-background transition-colors">
                        <i className="fab fa-facebook text-xl"></i>
                      </a>
                      <a href="#" className="text-background/80 hover:text-background transition-colors">
                        <i className="fab fa-twitter text-xl"></i>
                      </a>
                      <a href="#" className="text-background/80 hover:text-background transition-colors">
                        <i className="fab fa-instagram text-xl"></i>
                      </a>
                      <a href="#" className="text-background/80 hover:text-background transition-colors">
                        <i className="fab fa-linkedin text-xl"></i>
                      </a>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-4">Quick Links</h4>
                    <ul className="space-y-2">
                      <li><a href="/about" className="text-background/80 hover:text-background transition-colors">About Us</a></li>
                      <li><a href="/work" className="text-background/80 hover:text-background transition-colors">Our Work</a></li>
                      <li><a href="/stories" className="text-background/80 hover:text-background transition-colors">Stories</a></li>
                      <li><a href="/recognition" className="text-background/80 hover:text-background transition-colors">Recognition</a></li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-4">Get Involved</h4>
                    <ul className="space-y-2">
                      <li><a href="/donate" className="text-background/80 hover:text-background transition-colors">Donate</a></li>
                      <li><a href="#" className="text-background/80 hover:text-background transition-colors">Volunteer</a></li>
                      <li><a href="#" className="text-background/80 hover:text-background transition-colors">Partner with Us</a></li>
                      <li><a href="/contact" className="text-background/80 hover:text-background transition-colors">Contact</a></li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-4">Contact Info</h4>
                    <div className="space-y-2 text-background/80">
                      <p>123 Mission Street<br />San Francisco, CA 94103</p>
                      <p>Phone: +1 (555) 123-4567</p>
                      <p>Email: info@missionconnect.org</p>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-background/20 mt-8 pt-8 text-center">
                  <p className="text-background/80">
                    © 2024 MissionConnect. All rights reserved. | 
                    <a href="#" className="hover:text-background transition-colors"> Privacy Policy</a> | 
                    <a href="#" className="hover:text-background transition-colors"> Terms of Service</a>
                  </p>
                </div>
              </div>
            </footer>
          </div>
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
