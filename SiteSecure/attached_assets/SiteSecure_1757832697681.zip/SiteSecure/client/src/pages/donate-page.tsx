import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Lock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import PayPalButton from "@/components/PayPalButton";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const donationSchema = z.object({
  amount: z.number().min(1, "Amount must be at least $1"),
  donationType: z.enum(["one-time", "monthly"]),
  paymentMethod: z.enum(["stripe", "paypal", "gcash"]),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  message: z.string().optional(),
});

type DonationForm = z.infer<typeof donationSchema>;

const CheckoutForm = ({ formData }: { formData: DonationForm }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your donation!",
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <Button type="submit" className="w-full" disabled={!stripe} data-testid="stripe-submit-button">
        Complete Donation
      </Button>
    </form>
  );
};

export default function DonatePage() {
  const [clientSecret, setClientSecret] = useState("");
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const { toast } = useToast();

  const form = useForm<DonationForm>({
    resolver: zodResolver(donationSchema),
    defaultValues: {
      donationType: "one-time",
      paymentMethod: "stripe",
    },
  });

  const createPaymentIntent = useMutation({
    mutationFn: async (amount: number) => {
      const res = await apiRequest("POST", "/api/create-payment-intent", { amount });
      return await res.json();
    },
    onSuccess: (data) => {
      setClientSecret(data.clientSecret);
    },
    onError: (error: Error) => {
      toast({
        title: "Payment setup failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveDonation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/donations", data);
      return await res.json();
    },
  });

  const predefinedAmounts = [
    { value: 25, description: "Provides school supplies" },
    { value: 50, description: "Feeds a family for a week" },
    { value: 100, description: "Medical supplies" },
    { value: 250, description: "Water well contribution" },
  ];

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    form.setValue("amount", amount);
  };

  const onSubmit = async (data: DonationForm) => {
    if (data.paymentMethod === "stripe") {
      createPaymentIntent.mutate(data.amount);
    } else if (data.paymentMethod === "paypal") {
      // PayPal integration handled by PayPalButton component
      saveDonation.mutate({
        amount: data.amount * 100, // Convert to cents
        currency: "USD",
        paymentMethod: data.paymentMethod,
        donorName: `${data.firstName} ${data.lastName}`,
        donorEmail: data.email,
        message: data.message,
      });
    } else if (data.paymentMethod === "gcash") {
      // GCash integration would go here
      toast({
        title: "GCash Integration",
        description: "GCash payment processing would be implemented here",
      });
    }
  };

  return (
    <section className="py-16 bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="donate-title">
            Make a Donation
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="donate-description">
            Your generous contribution helps us continue our mission of creating positive change in communities worldwide.
          </p>
        </div>
        
        <div className="bg-card rounded-lg shadow-sm p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Donation Amount */}
              <div>
                <Label className="block text-sm font-medium text-foreground mb-3">Select Donation Amount</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4" data-testid="amount-buttons">
                  {predefinedAmounts.map((amount) => (
                    <button
                      key={amount.value}
                      type="button"
                      onClick={() => handleAmountSelect(amount.value)}
                      className={`border rounded-lg p-4 text-center hover:border-primary hover:bg-primary/5 transition-colors ${
                        selectedAmount === amount.value ? "border-primary bg-primary/5" : "border-border"
                      }`}
                      data-testid={`amount-button-${amount.value}`}
                    >
                      <div className="text-2xl font-bold text-foreground">${amount.value}</div>
                      <div className="text-sm text-muted-foreground">{amount.description}</div>
                    </button>
                  ))}
                </div>
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Custom Amount ($)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="Enter custom amount"
                          {...field}
                          onChange={(e) => {
                            const value = parseFloat(e.target.value);
                            field.onChange(value);
                            setSelectedAmount(value);
                          }}
                          data-testid="custom-amount-input"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {/* Donation Type */}
              <FormField
                control={form.control}
                name="donationType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Donation Type</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-2 gap-3"
                        data-testid="donation-type-radio"
                      >
                        <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors">
                          <RadioGroupItem value="one-time" id="one-time" className="sr-only" />
                          <Label htmlFor="one-time" className="cursor-pointer">
                            <div className="text-center">
                              <div className="font-semibold text-foreground">One-time</div>
                              <div className="text-sm text-muted-foreground">Make a single donation</div>
                            </div>
                          </Label>
                        </div>
                        <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors">
                          <RadioGroupItem value="monthly" id="monthly" className="sr-only" />
                          <Label htmlFor="monthly" className="cursor-pointer">
                            <div className="text-center">
                              <div className="font-semibold text-foreground">Monthly</div>
                              <div className="text-sm text-muted-foreground">Recurring donation</div>
                            </div>
                          </Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Payment Method */}
              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Method</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-1 md:grid-cols-3 gap-3"
                        data-testid="payment-method-radio"
                      >
                        <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors">
                          <RadioGroupItem value="stripe" id="stripe" className="sr-only" />
                          <Label htmlFor="stripe" className="cursor-pointer">
                            <div className="flex items-center justify-center">
                              <i className="fab fa-cc-stripe text-2xl text-blue-600 mr-2"></i>
                              <span className="font-medium">Stripe</span>
                            </div>
                          </Label>
                        </div>
                        <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors">
                          <RadioGroupItem value="paypal" id="paypal" className="sr-only" />
                          <Label htmlFor="paypal" className="cursor-pointer">
                            <div className="flex items-center justify-center">
                              <i className="fab fa-paypal text-2xl text-blue-500 mr-2"></i>
                              <span className="font-medium">PayPal</span>
                            </div>
                          </Label>
                        </div>
                        <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors">
                          <RadioGroupItem value="gcash" id="gcash" className="sr-only" />
                          <Label htmlFor="gcash" className="cursor-pointer">
                            <div className="flex items-center justify-center">
                              <i className="fas fa-mobile-alt text-2xl text-blue-700 mr-2"></i>
                              <span className="font-medium">GCash</span>
                            </div>
                          </Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Donor Information */}
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="first-name-input" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="last-name-input" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} data-testid="email-input" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Message (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Share why you're supporting our mission..." 
                        {...field} 
                        data-testid="message-textarea"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Payment Processing */}
              {form.watch("paymentMethod") === "stripe" && clientSecret && (
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <CheckoutForm formData={form.getValues()} />
                </Elements>
              )}
              
              {form.watch("paymentMethod") === "paypal" && (
                <div className="text-center">
                  <PayPalButton
                    amount={form.watch("amount")?.toString() || "0"}
                    currency="USD"
                    intent="CAPTURE"
                  />
                </div>
              )}
              
              {form.watch("paymentMethod") === "gcash" && (
                <Button type="submit" className="w-full" data-testid="gcash-submit-button">
                  Complete Donation with GCash
                </Button>
              )}
              
              {form.watch("paymentMethod") === "stripe" && !clientSecret && (
                <Button type="submit" className="w-full" data-testid="setup-payment-button">
                  Setup Payment
                </Button>
              )}
            </form>
          </Form>
        </div>
        
        {/* Security Notice */}
        <div className="text-center mt-8">
          <div className="flex items-center justify-center text-sm text-muted-foreground">
            <Lock className="h-4 w-4 mr-2" />
            <span>Your donation is secure and encrypted. We never store your payment information.</span>
          </div>
        </div>
      </div>
    </section>
  );
}
