import { Trophy, Tag, Medal, Star, Handshake, Globe } from "lucide-react";

export default function RecognitionPage() {
  const awards = [
    {
      icon: Trophy,
      title: "Excellence in Humanitarian Work",
      organization: "Global Charity Awards 2023",
      description: "Recognized for outstanding impact in education and healthcare initiatives",
      color: "primary"
    },
    {
      icon: Tag,
      title: "Transparency Seal",
      organization: "GuideStar Gold Seal 2023",
      description: "Highest level of transparency in nonprofit operations and reporting",
      color: "secondary"
    },
    {
      icon: Medal,
      title: "Innovation in Development",
      organization: "UN SDG Action Awards 2022",
      description: "Innovative approaches to sustainable development goals",
      color: "accent"
    },
    {
      icon: Star,
      title: "4-Star Rating",
      organization: "Charity Navigator 2023",
      description: "Exceptional accountability and financial health rating",
      color: "primary"
    },
    {
      icon: Handshake,
      title: "Partnership Excellence",
      organization: "USAID Partnership Award 2022",
      description: "Outstanding collaboration in international development",
      color: "secondary"
    },
    {
      icon: Globe,
      title: "Global Impact Recognition",
      organization: "World Economic Forum 2021",
      description: "Recognized as a leader in sustainable community development",
      color: "accent"
    }
  ];

  const financialStats = [
    { percentage: "92%", label: "Program Expenses", color: "primary" },
    { percentage: "5%", label: "Administrative", color: "secondary" },
    { percentage: "3%", label: "Fundraising", color: "accent" },
    { rating: "A+", label: "Overall Rating", color: "primary" }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="recognition-title">
            Recognition & Awards
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="recognition-description">
            Our commitment to excellence and transparency has been recognized by organizations worldwide.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16" data-testid="awards-grid">
          {awards.map((award, index) => {
            const IconComponent = award.icon;
            return (
              <div key={index} className="bg-card rounded-lg p-6 text-center shadow-sm" data-testid={`award-${index}`}>
                <div className={`w-16 h-16 bg-${award.color}/10 rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <IconComponent className={`text-${award.color} h-8 w-8`} />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2" data-testid={`award-title-${index}`}>
                  {award.title}
                </h3>
                <p className="text-muted-foreground mb-2" data-testid={`award-organization-${index}`}>
                  {award.organization}
                </p>
                <div className="text-sm text-muted-foreground" data-testid={`award-description-${index}`}>
                  {award.description}
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="bg-muted rounded-lg p-8" data-testid="financial-transparency">
          <h2 className="text-3xl font-bold text-foreground mb-6 text-center" data-testid="financial-title">
            Financial Transparency
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            {financialStats.map((stat, index) => (
              <div key={index} data-testid={`financial-stat-${index}`}>
                <div className={`text-3xl font-bold text-${stat.color} mb-2`} data-testid={`stat-value-${index}`}>
                  {stat.percentage || stat.rating}
                </div>
                <div className="text-muted-foreground" data-testid={`stat-label-${index}`}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
