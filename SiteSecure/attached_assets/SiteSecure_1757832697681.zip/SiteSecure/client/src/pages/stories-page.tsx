export default function StoriesPage() {
  const stories = [
    {
      id: 1,
      name: "Maria Rodriguez",
      location: "Guatemala",
      category: "Education Success",
      image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      title: "Maria's Journey to University",
      quote: "Thanks to the scholarship program, I was able to complete my education and become the first in my family to attend university. Now I'm studying to become a teacher so I can help other children in my community.",
      role: "Scholarship Recipient"
    },
    {
      id: 2,
      name: "James Mwangi",
      location: "Kenya",
      category: "Agriculture",
      image: "https://pixabay.com/get/gad761e6c03cb9bfdacf64bf6a1b061bcb8ef0d44fc11fee2e67bb9758ed5929b5ed4cec9291ccd028dfbcb2005b35e927ddb4a5c65db3d4f9c441eb92d4bc8b8_1280.jpg",
      title: "Growing Hope with James",
      quote: "The sustainable farming techniques we learned have transformed our village. Our crops are healthier, our income has tripled, and we're able to feed our families year-round. This knowledge is being passed down to the next generation.",
      role: "Farmer"
    },
    {
      id: 3,
      name: "Dr. Sarah Chen",
      location: "Cambodia",
      category: "Healthcare",
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      title: "Healing Communities with Dr. Sarah",
      quote: "Establishing the mobile clinic has been life-changing for our remote villages. We've reduced infant mortality by 60% and provided essential healthcare to over 3,000 people who previously had no access to medical services.",
      role: "Mobile Clinic Director"
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="stories-title">
            Stories of Impact
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="stories-description">
            Real stories from the communities we serve, showcasing the transformative power of collective action.
          </p>
        </div>
        
        <div className="space-y-12" data-testid="stories-list">
          {stories.map((story, index) => (
            <div 
              key={story.id}
              className={`grid lg:grid-cols-2 gap-8 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}
              data-testid={`story-${story.id}`}
            >
              <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                <img 
                  src={story.image} 
                  alt={`${story.name}'s story`} 
                  className="rounded-lg shadow-lg w-full h-96 object-cover"
                  data-testid={`story-image-${story.id}`}
                />
              </div>
              <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                <div className="bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium inline-block mb-4" data-testid={`story-category-${story.id}`}>
                  {story.category}
                </div>
                <h2 className="text-3xl font-bold text-foreground mb-4" data-testid={`story-title-${story.id}`}>
                  {story.title}
                </h2>
                <p className="text-lg text-muted-foreground mb-6" data-testid={`story-quote-${story.id}`}>
                  "{story.quote}"
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
                    <span className="text-primary-foreground font-bold" data-testid={`story-initial-${story.id}`}>
                      {story.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <div className="font-semibold text-foreground" data-testid={`story-name-${story.id}`}>
                      {story.name}
                    </div>
                    <div className="text-sm text-muted-foreground" data-testid={`story-role-${story.id}`}>
                      {story.role}, {story.location}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
