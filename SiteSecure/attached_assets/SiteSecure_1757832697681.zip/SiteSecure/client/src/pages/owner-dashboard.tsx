import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { LogOut, Trash2, Users, Activity, Shield, Clock } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertUserSchema, User } from "@shared/schema";

const createAdminSchema = insertUserSchema.pick({
  fullName: true,
  email: true,
  username: true,
  password: true,
});

type CreateAdminForm = z.infer<typeof createAdminSchema>;

export default function OwnerDashboard() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const form = useForm<CreateAdminForm>({
    resolver: zodResolver(createAdminSchema),
  });

  // Fetch admin users
  const { data: admins, isLoading } = useQuery<User[]>({
    queryKey: ["/api/admins"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Create admin mutation
  const createAdminMutation = useMutation({
    mutationFn: async (data: CreateAdminForm) => {
      const res = await apiRequest("POST", "/api/admin", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Admin created successfully",
        description: "The new admin account has been created.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/admins"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create admin",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete admin mutation
  const deleteAdminMutation = useMutation({
    mutationFn: async (adminId: string) => {
      const res = await apiRequest("DELETE", `/api/admin/${adminId}`);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Admin deleted successfully",
        description: "The admin account has been removed.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admins"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete admin",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CreateAdminForm) => {
    createAdminMutation.mutate(data);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleDeleteAdmin = (adminId: string) => {
    if (window.confirm("Are you sure you want to delete this admin account?")) {
      deleteAdminMutation.mutate(adminId);
    }
  };

  if (!user || user.role !== "owner") {
    return <div>Access denied</div>;
  }

  return (
    <section className="py-8 bg-background min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-foreground" data-testid="owner-dashboard-title">
            Owner Dashboard
          </h1>
          <Button
            onClick={handleLogout}
            variant="destructive"
            data-testid="logout-button"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Admin Management */}
          <div className="lg:col-span-2">
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="text-2xl" data-testid="admin-management-title">
                  Admin Account Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Create New Admin */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-foreground mb-4" data-testid="create-admin-title">
                    Create New Admin
                  </h3>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="fullName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input {...field} value={field.value || ""} data-testid="new-admin-name" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" {...field} data-testid="new-admin-email" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Username</FormLabel>
                              <FormControl>
                                <Input {...field} data-testid="new-admin-username" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} data-testid="new-admin-password" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <Button 
                        type="submit" 
                        disabled={createAdminMutation.isPending}
                        data-testid="create-admin-button"
                      >
                        {createAdminMutation.isPending ? "Creating..." : "Create Admin Account"}
                      </Button>
                    </form>
                  </Form>
                </div>

                {/* Existing Admins */}
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4" data-testid="existing-admins-title">
                    Existing Admin Accounts
                  </h3>
                  {isLoading ? (
                    <div className="text-muted-foreground">Loading admins...</div>
                  ) : (
                    <div className="space-y-3" data-testid="admins-list">
                      {admins && admins.length > 0 ? (
                        admins.map((admin) => (
                          <div
                            key={admin.id}
                            className="flex items-center justify-between p-4 border border-border rounded-lg"
                            data-testid={`admin-item-${admin.id}`}
                          >
                            <div>
                              <div className="font-medium text-foreground" data-testid={`admin-name-${admin.id}`}>
                                {admin.fullName || admin.username}
                              </div>
                              <div className="text-sm text-muted-foreground" data-testid={`admin-email-${admin.id}`}>
                                {admin.email}
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="secondary" data-testid={`admin-status-${admin.id}`}>
                                Active
                              </Badge>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteAdmin(admin.id)}
                                disabled={deleteAdminMutation.isPending}
                                data-testid={`delete-admin-${admin.id}`}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-muted-foreground text-center py-8">
                          No admin accounts found
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <div>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg" data-testid="quick-stats-title">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between" data-testid="total-admins-stat">
                  <span className="text-muted-foreground">Total Admins</span>
                  <span className="font-semibold text-foreground">
                    {admins?.length || 0}
                  </span>
                </div>
                <div className="flex justify-between" data-testid="active-sessions-stat">
                  <span className="text-muted-foreground">Active Sessions</span>
                  <span className="font-semibold text-foreground">1</span>
                </div>
                <div className="flex justify-between" data-testid="last-login-stat">
                  <span className="text-muted-foreground">Last Login</span>
                  <span className="font-semibold text-foreground">Now</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg" data-testid="system-status-title">System Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center" data-testid="website-status">
                  <div className="w-3 h-3 bg-secondary rounded-full mr-3"></div>
                  <span className="text-foreground">Website Online</span>
                </div>
                <div className="flex items-center" data-testid="database-status">
                  <div className="w-3 h-3 bg-secondary rounded-full mr-3"></div>
                  <span className="text-foreground">Database Connected</span>
                </div>
                <div className="flex items-center" data-testid="payment-status">
                  <div className="w-3 h-3 bg-secondary rounded-full mr-3"></div>
                  <span className="text-foreground">Payment Systems Active</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
