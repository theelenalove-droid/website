import { CheckCircle } from "lucide-react";

export default function AboutPage() {
  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="about-title">
            About MissionConnect
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="about-description">
            Founded with a vision to bridge communities and create lasting change, we've been at the forefront of humanitarian work for over a decade.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-6" data-testid="mission-title">Our Mission</h2>
            <p className="text-lg text-muted-foreground mb-6" data-testid="mission-description">
              We believe that every person deserves access to basic human needs: education, healthcare, clean water, and economic opportunity. Our mission is to connect resources with communities in need, creating sustainable solutions that empower people to build better futures.
            </p>
            <div className="space-y-4">
              <div className="flex items-start">
                <CheckCircle className="text-secondary text-xl mr-3 mt-1 h-5 w-5" />
                <div>
                  <h3 className="font-semibold text-foreground" data-testid="value-1-title">Sustainable Impact</h3>
                  <p className="text-muted-foreground" data-testid="value-1-description">We focus on long-term solutions that communities can maintain and grow.</p>
                </div>
              </div>
              <div className="flex items-start">
                <CheckCircle className="text-secondary text-xl mr-3 mt-1 h-5 w-5" />
                <div>
                  <h3 className="font-semibold text-foreground" data-testid="value-2-title">Community-Led</h3>
                  <p className="text-muted-foreground" data-testid="value-2-description">Local communities lead our projects, ensuring cultural sensitivity and relevance.</p>
                </div>
              </div>
              <div className="flex items-start">
                <CheckCircle className="text-secondary text-xl mr-3 mt-1 h-5 w-5" />
                <div>
                  <h3 className="font-semibold text-foreground" data-testid="value-3-title">Transparent Operations</h3>
                  <p className="text-muted-foreground" data-testid="value-3-description">Every dollar is tracked and reported to ensure maximum impact.</p>
                </div>
              </div>
            </div>
          </div>
          <div>
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Our team working together" 
              className="rounded-lg shadow-lg"
              data-testid="team-image"
            />
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8" data-testid="core-values">
          <div className="text-center">
            <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-heart text-primary text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="core-value-1-title">Compassion</h3>
            <p className="text-muted-foreground" data-testid="core-value-1-description">We approach every situation with empathy and understanding.</p>
          </div>
          <div className="text-center">
            <div className="bg-secondary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-handshake text-secondary text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="core-value-2-title">Partnership</h3>
            <p className="text-muted-foreground" data-testid="core-value-2-description">We work alongside communities as partners, not just donors.</p>
          </div>
          <div className="text-center">
            <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-lightbulb text-accent text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="core-value-3-title">Innovation</h3>
            <p className="text-muted-foreground" data-testid="core-value-3-description">We use creative solutions to solve complex challenges.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
