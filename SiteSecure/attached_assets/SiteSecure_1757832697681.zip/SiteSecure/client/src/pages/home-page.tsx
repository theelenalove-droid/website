import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { getQueryFn } from "@/lib/queryClient";
import { ContentSection } from "@shared/schema";

export default function HomePage() {
  const { data: content } = useQuery<ContentSection[]>({
    queryKey: ["/api/content/homepage"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const heroContent = content?.find(c => c.section === "hero");
  const statsContent = content?.find(c => c.section === "stats");

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{
            backgroundImage: `url('${heroContent?.imageUrl || "https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"}')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/80 to-emerald-500/60"></div>
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 25px 25px, rgba(255, 255, 255, 0.1) 2%, transparent 0%)",
          backgroundSize: "50px 50px"
        }}></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6" data-testid="hero-title">
              {heroContent?.title || "Making a Difference, One Mission at a Time"}
            </h1>
            <p className="text-xl lg:text-2xl text-white/90 mb-8 max-w-3xl mx-auto" data-testid="hero-description">
              {heroContent?.description || "Join our community of changemakers as we work together to create lasting impact in communities around the world."}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/donate">
                <Button 
                  size="lg" 
                  className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-4 text-lg"
                  data-testid="hero-donate-button"
                >
                  Donate Now
                </Button>
              </Link>
              <Link href="/about">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="bg-white/10 text-white border-white/20 hover:bg-white/20 px-8 py-4 text-lg"
                  data-testid="hero-learn-more-button"
                >
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Stats */}
      <section className="py-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8" data-testid="impact-stats">
            {statsContent?.content && (statsContent.content as any)?.stats ? (
              (statsContent.content as any).stats.map((stat: any, index: number) => (
                <div key={index} className="text-center">
                  <div className="text-4xl font-bold text-primary mb-2" data-testid={`stat-value-${index}`}>
                    {stat.value}
                  </div>
                  <div className="text-muted-foreground" data-testid={`stat-label-${index}`}>
                    {stat.label}
                  </div>
                </div>
              ))
            ) : (
              <>
                <div className="text-center">
                  <div className="text-4xl font-bold text-primary mb-2">50K+</div>
                  <div className="text-muted-foreground">Lives Impacted</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-secondary mb-2">25</div>
                  <div className="text-muted-foreground">Countries Reached</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-accent mb-2">100+</div>
                  <div className="text-muted-foreground">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-primary mb-2">1M+</div>
                  <div className="text-muted-foreground">Funds Raised</div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Featured Programs */}
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="programs-title">
              Our Programs
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="programs-description">
              Discover how we're making a difference through targeted initiatives designed to address the world's most pressing challenges.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-testid="programs-grid">
            <div className="bg-card rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              <img 
                src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
                alt="Education program" 
                className="w-full h-48 object-cover"
                data-testid="program-image-1"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="program-title-1">
                  Education Initiative
                </h3>
                <p className="text-muted-foreground mb-4" data-testid="program-description-1">
                  Providing quality education and learning resources to underserved communities worldwide.
                </p>
                <Link href="/work" className="text-primary font-medium hover:text-primary/80">
                  Learn More →
                </Link>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              <img 
                src="https://pixabay.com/get/g8bfe450bf4e27642e1895273a5d9efcac8554ecb86e87efc3060b2f2dc9edcd90ea5330deafe8240a46f45337b10a1fbfa167d42011e0fda03e224bc5c73a8cf_1280.jpg" 
                alt="Healthcare program" 
                className="w-full h-48 object-cover"
                data-testid="program-image-2"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="program-title-2">
                  Healthcare Access
                </h3>
                <p className="text-muted-foreground mb-4" data-testid="program-description-2">
                  Bringing essential medical services and health education to remote and underserved areas.
                </p>
                <Link href="/work" className="text-primary font-medium hover:text-primary/80">
                  Learn More →
                </Link>
              </div>
            </div>
            
            <div className="bg-card rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              <img 
                src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300" 
                alt="Sustainability program" 
                className="w-full h-48 object-cover"
                data-testid="program-image-3"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="program-title-3">
                  Sustainability Project
                </h3>
                <p className="text-muted-foreground mb-4" data-testid="program-description-3">
                  Supporting eco-friendly practices and sustainable development in rural communities.
                </p>
                <Link href="/work" className="text-primary font-medium hover:text-primary/80">
                  Learn More →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-4" data-testid="cta-title">
            Ready to Make a Difference?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto" data-testid="cta-description">
            Join thousands of supporters who are helping us create positive change around the world.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/donate">
              <Button 
                size="lg" 
                className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-4 text-lg"
                data-testid="cta-donate-button"
              >
                Start Donating
              </Button>
            </Link>
            <Link href="/contact">
              <Button 
                variant="outline" 
                size="lg" 
                className="bg-white/10 text-primary-foreground border-white/20 hover:bg-white/20 px-8 py-4 text-lg"
                data-testid="cta-contact-button"
              >
                Get Involved
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
