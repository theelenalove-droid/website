import { Users, GraduationCap } from "lucide-react";

export default function WorkPage() {
  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6" data-testid="work-title">
            Our Work
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="work-description">
            Explore our ongoing projects and see how we're making a difference in communities around the world.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8 mb-16" data-testid="projects-grid">
          <div className="bg-card rounded-lg shadow-sm overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Water project" 
              className="w-full h-64 object-cover"
              data-testid="project-image-1"
            />
            <div className="p-6">
              <div className="flex items-center mb-2">
                <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium" data-testid="project-category-1">
                  Water Access
                </span>
                <span className="ml-auto text-sm text-muted-foreground" data-testid="project-location-1">
                  Kenya, Africa
                </span>
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3" data-testid="project-title-1">
                Clean Water Initiative
              </h3>
              <p className="text-muted-foreground mb-4" data-testid="project-description-1">
                Installing sustainable water systems in rural communities, providing access to clean drinking water for over 5,000 people in 15 villages.
              </p>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Users className="text-muted-foreground mr-2 h-4 w-4" />
                  <span className="text-sm text-muted-foreground" data-testid="project-beneficiaries-1">
                    5,247 beneficiaries
                  </span>
                </div>
                <button className="text-primary font-medium hover:text-primary/80" data-testid="project-details-1">
                  View Details →
                </button>
              </div>
            </div>
          </div>
          
          <div className="bg-card rounded-lg shadow-sm overflow-hidden">
            <img 
              src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Education project" 
              className="w-full h-64 object-cover"
              data-testid="project-image-2"
            />
            <div className="p-6">
              <div className="flex items-center mb-2">
                <span className="bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm font-medium" data-testid="project-category-2">
                  Education
                </span>
                <span className="ml-auto text-sm text-muted-foreground" data-testid="project-location-2">
                  Guatemala
                </span>
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3" data-testid="project-title-2">
                School Building Project
              </h3>
              <p className="text-muted-foreground mb-4" data-testid="project-description-2">
                Constructing new classrooms and providing educational materials to ensure quality education for children in underserved areas.
              </p>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <GraduationCap className="text-muted-foreground mr-2 h-4 w-4" />
                  <span className="text-sm text-muted-foreground" data-testid="project-beneficiaries-2">
                    1,200 students
                  </span>
                </div>
                <button className="text-primary font-medium hover:text-primary/80" data-testid="project-details-2">
                  View Details →
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-muted rounded-lg p-8" data-testid="impact-map">
          <h2 className="text-3xl font-bold text-foreground mb-6 text-center" data-testid="impact-map-title">
            Project Impact Map
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2" data-testid="stat-active-projects">12</div>
              <div className="text-muted-foreground">Active Projects</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary mb-2" data-testid="stat-countries">8</div>
              <div className="text-muted-foreground">Countries</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-accent mb-2" data-testid="stat-people-served">25K+</div>
              <div className="text-muted-foreground">People Served</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2" data-testid="stat-success-rate">95%</div>
              <div className="text-muted-foreground">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
