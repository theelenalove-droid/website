import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogOut, Upload, Home, Info, Briefcase, BookOpen, Trash2, Plus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertContentSectionSchema, ContentSection } from "@shared/schema";

const contentFormSchema = insertContentSectionSchema;
type ContentForm = z.infer<typeof contentFormSchema>;

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [activeSection, setActiveSection] = useState("homepage");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const form = useForm<ContentForm>({
    resolver: zodResolver(contentFormSchema),
    defaultValues: {
      page: "homepage",
      section: "hero",
    },
  });

  // Fetch content for the active section
  const { data: content, isLoading } = useQuery<ContentSection[]>({
    queryKey: ["/api/content", activeSection],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Upload file mutation
  const uploadFileMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("image", file);
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Upload failed");
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "File uploaded successfully",
        description: "You can now use this image in your content.",
      });
      form.setValue("imageUrl", data.url);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create/Update content mutation
  const saveContentMutation = useMutation({
    mutationFn: async (data: ContentForm) => {
      const res = await apiRequest("POST", "/api/content", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Content saved successfully",
        description: "Your changes have been published.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to save content",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update content mutation
  const updateContentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<ContentForm> }) => {
      const res = await apiRequest("PUT", `/api/content/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Content updated successfully",
        description: "Your changes have been published.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update content",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = () => {
    if (selectedFile) {
      uploadFileMutation.mutate(selectedFile);
    }
  };

  const onSubmit = (data: ContentForm) => {
    saveContentMutation.mutate({
      ...data,
      page: activeSection,
    });
  };

  const sections = [
    { id: "homepage", name: "Homepage", icon: Home },
    { id: "about", name: "About Us", icon: Info },
    { id: "work", name: "Our Work", icon: Briefcase },
    { id: "stories", name: "Stories", icon: BookOpen },
  ];

  if (!user || (user.role !== "admin" && user.role !== "owner")) {
    return <div>Access denied</div>;
  }

  return (
    <section className="py-8 bg-background min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-foreground" data-testid="admin-dashboard-title">
            Content Management
          </h1>
          <Button
            onClick={handleLogout}
            variant="destructive"
            data-testid="logout-button"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        <Tabs value={activeSection} onValueChange={setActiveSection} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8" data-testid="content-tabs">
            {sections.map((section) => {
              const IconComponent = section.icon;
              return (
                <TabsTrigger
                  key={section.id}
                  value={section.id}
                  className="flex items-center space-x-2"
                  data-testid={`tab-${section.id}`}
                >
                  <IconComponent className="h-4 w-4" />
                  <span>{section.name}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {sections.map((section) => (
            <TabsContent key={section.id} value={section.id}>
              <div className="grid lg:grid-cols-3 gap-8">
                {/* Content Form */}
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle data-testid={`${section.id}-editor-title`}>
                        Edit {section.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                          {/* Image Upload */}
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">
                              Upload Image
                            </label>
                            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                              <p className="text-muted-foreground mb-4">
                                {selectedFile ? selectedFile.name : "Choose an image file"}
                              </p>
                              <input
                                type="file"
                                accept="image/*"
                                onChange={handleFileChange}
                                className="hidden"
                                id="image-upload"
                                data-testid="image-upload-input"
                              />
                              <label htmlFor="image-upload">
                                <Button
                                  type="button"
                                  variant="outline"
                                  className="cursor-pointer"
                                  data-testid="choose-file-button"
                                >
                                  Choose File
                                </Button>
                              </label>
                              {selectedFile && (
                                <Button
                                  type="button"
                                  onClick={handleUpload}
                                  disabled={uploadFileMutation.isPending}
                                  className="ml-2"
                                  data-testid="upload-button"
                                >
                                  {uploadFileMutation.isPending ? "Uploading..." : "Upload"}
                                </Button>
                              )}
                            </div>
                          </div>

                          <FormField
                            control={form.control}
                            name="section"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Section</FormLabel>
                                <FormControl>
                                  <Input {...field} placeholder="e.g., hero, stats, programs" data-testid="section-input" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Title</FormLabel>
                                <FormControl>
                                  <Input {...field} value={field.value || ""} data-testid="title-input" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} value={field.value || ""} rows={4} data-testid="description-textarea" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="imageUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Image URL</FormLabel>
                                <FormControl>
                                  <Input {...field} value={field.value || ""} placeholder="Image URL from upload or external source" data-testid="image-url-input" />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <Button
                            type="submit"
                            disabled={saveContentMutation.isPending}
                            data-testid="save-content-button"
                          >
                            {saveContentMutation.isPending ? "Saving..." : "Save Content"}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </div>

                {/* Existing Content */}
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle data-testid={`${section.id}-content-list-title`}>
                        Existing Content
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isLoading ? (
                        <div className="text-muted-foreground">Loading content...</div>
                      ) : (
                        <div className="space-y-4" data-testid={`${section.id}-content-list`}>
                          {content && content.length > 0 ? (
                            content.map((item) => (
                              <div
                                key={item.id}
                                className="border border-border rounded-lg p-4"
                                data-testid={`content-item-${item.id}`}
                              >
                                <div className="flex justify-between items-start mb-2">
                                  <h4 className="font-medium text-foreground" data-testid={`content-title-${item.id}`}>
                                    {item.title || `${item.section} section`}
                                  </h4>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      form.setValue("section", item.section);
                                      form.setValue("title", item.title || "");
                                      form.setValue("description", item.description || "");
                                      form.setValue("imageUrl", item.imageUrl || "");
                                    }}
                                    data-testid={`edit-content-${item.id}`}
                                  >
                                    Edit
                                  </Button>
                                </div>
                                <p className="text-sm text-muted-foreground mb-2" data-testid={`content-section-${item.id}`}>
                                  Section: {item.section}
                                </p>
                                {item.description && (
                                  <p className="text-sm text-muted-foreground truncate" data-testid={`content-description-${item.id}`}>
                                    {item.description}
                                  </p>
                                )}
                                {item.imageUrl && (
                                  <img
                                    src={item.imageUrl}
                                    alt={item.title || "Content image"}
                                    className="w-full h-24 object-cover rounded mt-2"
                                    data-testid={`content-image-${item.id}`}
                                  />
                                )}
                              </div>
                            ))
                          ) : (
                            <div className="text-muted-foreground text-center py-8">
                              No content found for this page
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}
